Stealth Bastard Community Levels
--------------------------------

Copy content with replacement to %APPDATA%\StealthBastard[Steam]
