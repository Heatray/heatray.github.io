Rare Hats Mod
-------------

The probability of rare hats for Royalist Officer and Royalist Dragon Rider
increased from 2% to 20% and for other enemies from 1% to 10%.

Copy files to the game folder.

heatray (c) 2021
